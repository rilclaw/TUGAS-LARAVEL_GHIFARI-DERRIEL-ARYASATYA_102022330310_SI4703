<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Product::truncate();

        Product::create(['name' => 'Nasi Goreng','price' => 25000.00]);
        Product::create(['name' => 'Sate Ayam', 'price' => 30000.00]);
        Product::create(['name' => 'Bakso','price' => 20000.00]);
    }
}
